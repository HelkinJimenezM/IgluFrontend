# Iglú backend skeleton

Instructions: add Firebase admin credentials and implement auth logic.
